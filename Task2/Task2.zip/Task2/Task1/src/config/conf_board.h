/**
 * \file
 *
 * \brief User board configuration template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef CONF_BOARD_H
#define CONF_BOARD_H

#define LED_PIN PIO_PA23_IDX
#define BUTTON_PIN PIO_PA22_IDX

#endif // CONF_BOARD_H
